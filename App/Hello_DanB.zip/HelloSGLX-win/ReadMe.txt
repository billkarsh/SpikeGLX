
Purpose:
Send a command or query to running SpikeGLX from external program.

Usage:
>HelloSGLX -cmd=command [ options ]

Options:
-host=127.0.0.1   ;ip4 SpikeGLX network address
-port=4142        ;ip4 port
-args=as_needed   ;optional command arguments

Notes:
- Separate multiple input args by '\n' chars.
- Output is sent to stdout stream.
- Multiple output values are '\n' separated lines.

Commands:
-cmd=justConnect
Returns lines: version, host, port.

-cmd=enumDataDir [-args=idir] (default 0)
Returns lines: files in data directory[idir].

-cmd=getDataDir [-args=idir] (default 0)
Returns data directory[idir].

-cmd=getImecChanGains -args=ip\nchan
Returns lines: AP and LF gain for probe ip, chan.

-cmd=getParams
Returns lines: key=value.

-cmd=getParamsImecCommon
Returns lines: key=value.

-cmd=getParamsImecProbe [-args=ip] (default 0)
Returns lines: key=value.

-cmd=getParamsOneBox [-args=ip] (default 0)
Returns lines: key=value.

-cmd=getProbeList
Returns string: (probeID,nShanks,partNumber)()...
// - A parenthesized entry for each selected probe.
// - probeID: zero-based integer.
// - nShanks: integer {1,4}.
// - partNumber: string, e.g., NP1000.
// - If no probes, return '()'.

-cmd=getRunName
Returns string: base run-name.

-cmd=getStreamAcqChans -args=js\nip
Returns lines: list of stream channel counts, as follows:
// js = 0: NI channels: {MN,MA,XA,DW}.
// js = 1: OB channels: {XA,DW,SY}.
// js = 2: IM channels: {AP,LF,SY}.

-cmd=getStreamI16ToVolts -args=js\nip\nchan
Return multiplier converting 16-bit binary channel to volts.

-cmd=getStreamMaxInt -args=js\nip
Return largest positive integer value for selected stream.

-cmd=getStreamNP -args=js
Return number (np) of js-type substreams.
// For the given js, ip has range [0..np-1].

-cmd=getStreamSampleRate -args=js\nip
Returns sample rate for given stream.

-cmd=getStreamSaveChans -args=js\nip
Returns lines: list of saved channels.

-cmd=getStreamSN -args=js\nip
Return type and serial number for stream.
// js = 1: Get OneBox slot and SN.
// js = 2: Get probe  type and SN.
// SN = serial number string.

-cmd=getStreamVoltageRange -args=js\nip
Returns lines: voltage range for given stream.

-cmd=getTime
Returns number of seconds since SpikeGLX launched.

-cmd=getVersion
Returns SpikeGLX version string.

-cmd=isInitialized
Returns 1 if SpikeGLX is launched and ready to run.

-cmd=isRunning
Returns 1 if SpikeGLX is acquiring data.

-cmd=isSaving
Returns 1 if SpikeGLX is writing file data.

-cmd=isUserOrder -args=js\nip
Returns 1 if main Graphs window set to User order for stream.

-cmd=opto_emit -args=ip\ncolor\nsite
Direct emission to specified site (-1=dark).
// ip:    imec probe index.
// color: {0=blue, 1=red}.
// site:  [0..13], or, -1=dark.

-cmd=opto_getAttenuations -args=ip\ncolor
Return list of 14 (double) site power attenuation factors.
// ip:    imec probe index.
// color: {0=blue, 1=red}.

-cmd=setAnatomy_Pinpoint -args=string
Set anatomy data string with Pinpoint format:
// [probe-id,shank-id](startpos,endpos,R,G,B,rgnname)(startpos,endpos,R,G,B,rgnname)…()
//    - probe-id: SpikeGLX logical probe id.
//    - shank-id: [0..n-shanks].
//    - startpos: region start in microns from tip.
//    - endpos:   region end in microns from tip.
//    - R,G,B:    region color as RGB, each [0..255].
//    - rgnname:  region name text.

-cmd=setAudioEnable -args=1
Set audio output on/off. Note that this command has
no effect if not currently running.

-cmd=setAudioParams -args=group\nkey=value...
Set subgroup of parameters for audio-out operation. Parameters
are a map of name/value pairs. This call stops current output.
Call setAudioEnable() to restart it.


Change Log
----------
Version 1.0
- Initial release.


