
Background
-----------
This opto-capable version of SpikeGLX has never been tested with hardware because our opto headstages are not working.

It is based upon an API version that is under development, and several things are known to be broken:

- You should have only one BS module in your chassis at a time because they may talk to each other and corrupt the sync signals.

- Choose either an external pulser for sync or make NI the sync source because the phase of the imec sync source is wrong.

Please report what seems to work and what doesn't.



Getting started
---------------
- Put your opto probe calibration folder into the SpikeGLX folder as usual.
- Notice the Configure Slots button in the Detect panel. Make choices **AND CLICK SET**.
- An opto module only has ports 1,2 but the table will show 4 ports, so ignore 3,4.
- Try using the opto basestation to run your existing NP 1.0 {cable, HS, probe) to verify basestation works. Do a run in air.
- Next keep the NP 1.0 probe, but plug it into an opto {cable, HS}. There are two flex connectors on an opto HS. YOU MUST USE THE CORRECT ONE!! ITS THE ONE CLOSER TO THE 6-PIN CABLE CONNECTOR. Do a run in air.
- If that works, try all opto parts to see if you can do a run in air without doing any opto switching (like any other probe).


Next
----
Let us know what happens with these tests...

We will send a MATLAB script to drive the opto functions in a few days.



