@echo off
:: Ensure the script is running with administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo.
echo Detecting current active power plan...

for /f "tokens=4,5 delims= " %%G in ('powercfg -getactivescheme') do set GUID=%%G

echo Active Power Plan GUID: %GUID%
echo.

echo Applying DAQ-optimized settings for PLUGGED-IN mode...
echo.

:: USB Selective Suspend - Disabled
powercfg /setacvalueindex %GUID% 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0

:: PCI Express Link State Power Management - Off
powercfg /setacvalueindex %GUID% SUB_PCIEXPRESS ASPM 0

:: Processor Minimum and Maximum States - 100%, Active Cooling
:: powercfg /setacvalueindex %GUID% SUB_PROCESSOR PROCTHROTTLEMIN 5
powercfg /setacvalueindex %GUID% SUB_PROCESSOR SYSCOOLPOL 1
powercfg /setacvalueindex %GUID% SUB_PROCESSOR PROCTHROTTLEMAX 100

:: Hard Disk - Never turn off
powercfg /setacvalueindex %GUID% SUB_DISK DISKIDLE 0

:: Sleep - Never
powercfg /setacvalueindex %GUID% SUB_SLEEP STANDBYIDLE 0

:: Hibernate - Never
powercfg /setacvalueindex %GUID% SUB_SLEEP HIBERNATEIDLE 0

:: Apply the updated plan
powercfg /s %GUID%

echo.
echo DAQ power settings successfully applied to plugged-in mode!
pause
