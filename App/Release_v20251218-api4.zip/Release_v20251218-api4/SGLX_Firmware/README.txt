
=========
IMPORTANT
=========

The Imec module (base station card) firmware files in this folder must be loaded into a module before it can be used.

Use the SpikeGLX menu item 'Tools/Update Imec Firmware' to load these files.

Read the help document in that dialog.

After loading the files, follow prompts to power cycle everything, or to restart SpikeGLX.

Once firmware is loaded, its version numbers are read back by pressing the 'Detect' button in the 'Configure Acquisition' dialog.


