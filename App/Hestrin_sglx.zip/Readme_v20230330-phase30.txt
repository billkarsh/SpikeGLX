Shaul,

These exes need to be placed into the SpikeGLX folder for Release_20230326-phase30.

They function the same as 20230326 except the FileViewer handles negative file offsets.

Bill


