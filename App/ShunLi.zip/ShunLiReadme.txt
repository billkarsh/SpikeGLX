The included:

SpikeGLX.exe
SpikeGLX_NSIM.exe
_Help

replace the like items from a download of 20230415-phase30.

The new feature is -<Tx> in the online and offline graphs.

It works the same as -<Tn>, but Tn is for neural channels and Tx is non-neural analogs.

Each of these calculates an average (per channel) over a one-second span and subtracts that from the channel.

The value is updated every 5 seconds.

