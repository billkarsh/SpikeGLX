Michael,

This build replaces the like exe in your existing opto setup.

The differences are:

- I am starting to reorganize the Config dialog items, so that may look a little different, but functions the same.

- The detect function makes a detailed log in the log window...


IMPORTANT:

1) Resize your SpikeGLX console/log window to make it tall.
2) Make sure the Config dialog is not covering the log window.
3) Whenever you click detect a long list of steps is shown in the log window.
4) If there is a hang, I want a screen shot. Hopefully you can get one.
-- I definitely want the log window in the shot.
-- The Config dialog is also useful in the shot.
-- Just get the whole screen if you can. (keyboard Print Screen should work).

The print screen function copies a screen shot to the clipboard, you can then paste it into the Windows Paint application in Accessories.

IMPORTANT:

If you can't get a screen shot, then writing down the log text is useful, especially the last several lines...what were the last things that did complete successfully before the hang?

Bill