
Purpose:
+ Convert Intan acquisition data to SpikeGLX run.
Run messages are appended to Intan2SGL.log in the app folder.

Usage:
>Intan2SGL -run=<out_run_name> -rhs=<filepath> -outdir=<path>

Notes:

- Experiment is assumed to consist of exactly 128 neural/stim channels but can include your choice of AI/DI channels.
- You can call Intan2SGL from a script.
- You can try it by editing the included 'runit.bat' file. Edit the file to set your own parameters. Then double-click the bat file to run it.
- Options must not have spaces.
- In *.bat files, continue long lines using <space><caret>. Like this ^.
- Remove all white space at line ends, especially after a caret (^).


Change Log
----------
Version 1.0
- Initial release.


