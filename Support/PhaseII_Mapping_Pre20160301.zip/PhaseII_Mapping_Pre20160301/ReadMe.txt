
Channel mapping files, in general
=================================

SpikeGLX uses a simple text file to describe how acquired data channels should be organized
among the Graph window tabs. These are called channel mapping files and have '.cmp' extension.
These files only affect the Graph Window view; they have nothing to do with the ordering of
channels in data files.

Below are a few lines from our example file: 'IMEC_PhsII_128Neural.cmp'.

	0,0,6,2,32,0,0 
	MN0C0;0 94
	MN0C1;1 90
	MN0C2;2 86
	MN0C3;3 82

The first line is a header. It describes how many channels of each type are being acquired.
The header fields are interpreted like this:

	#Phase3 spike channels:			0
	#Phase3 LFP channels:			0
	#Ni-Daq multiplexed neural channels:	6
	#Ni-Daq multiplexed analog channels:	2
	#channels/multiplexer:			32
	#Ni-Daq non-multiplexed analog chans:	0
	#Ni-Daq non-multiplexed digital words:	0

SpikeGLX requires that the channel types that you've set up in the Configure Dialog match the header in the mapping file, or it won't let you load that mapping file. See 'PhsII Configure Dialog.png' for the channel setup strings that go with this mapping file.

After the header line, each line in a mapping file has an acquisition channel name followed by a graph
number. A channel name might look like this:

	MN4C21;149

which means nidaq neural multiplexer 4 / multiplexer channel 21 ; 149th position in data stream. So a line
in the mapping file like this:

	MN4C21;149 35

would mean acquired channel #149 is displayed in graph #35. Each tab of the Graph Window typically shows
32 channels (0..31) so graph #35 would be the fourth graph on the second tab. The graphs are numbered
from left to right, top to bottom.

You can edit these files to arrange the channels in any order you like.


Loading a mapping file
======================

Set up a new run using the Configuration Dialog.

- In the See N'Save tab::Graph window options box, click 'Edit' to show the Channel Map dialog.
- In the Channel Map dialog, click 'Load' to select your mapping file.
- Click 'OK' to close the dialog.


Sorting in the Graphs Window
============================

When your run starts, click 'User order' to sort the graphs according to your mapping file.


IMEC_PhsII_128Neural.cmp
========================

In our example mapping file, the first tab gets 32 channels from the lower tip of the shank. The reference channels appear at graph positions #0 and #17. Each graph alternates between head-stages A/B, so going from
left to right the graphs are alternating between left and right edges of the shank.

The next tab shows the next higher block of 32 channels on the shank, and so on.

Because this file is set up for our usual 256-channel layout, tabs #5 and #6 have unused neural channels,
while tabs #7 and #8 show any auxiliary analog channels you have connected, in their acquisition order.






