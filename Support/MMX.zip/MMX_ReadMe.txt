
This special version of 20190327_3B2 contains a minimum number of modifications needed to support the connecting of each readout channel to three banks of the probe.

1) The imro table and its GUI editor normally specify a single bank index for each channel. In this version there are three values per channel: {bankA, bankB, bankC} stored in the imro table.

2) The setting of these three values into the probe switches works as follows:

connectChannelToBanks( channel, bankA, bankB, bankC )
{
	disconnectChannel( channel );
	connectChannelToBank( channel, bankA );
	if( bankB != bankA )
		connectChannelToBank( channel, bankB );
	if( bankC != bankA && bankC != bankA )
		connectChannelToBank( channel, bankC );
}

The effect is that each readout channel can be connected to 1, 2 or 3 banks at the same time, depending upon the values you set in the table.

Note 1: All other functions are basically unmodified. For example, the shank viewer depicts activity on the probe according to bankA values only.

Note 2: You must not share data files {imro tables, output meta data files} between this version and other versions of SpikeGLX because the format of the imro table does not match.




