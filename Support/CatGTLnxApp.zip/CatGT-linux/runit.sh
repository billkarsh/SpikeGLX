#!/bin/sh

# You can't call CatGT directly, rather, call it via runit.sh.
# You can call runit.sh two ways:
#
# 1) > runit.sh cmd-line-parameters
# 2a) Edit parameters in runit.sh, then call it ...
# 2b) > runit.sh
#
# This script effectively says:
# "If there are no parameters sent to runit.sh, call CatGT
# with the parameters hard coded here, else, pass all of the
# parameters through to CatGT."
#

if [ "$1" == "" ]
then
    SRC=/groups/apig/apig/Austin_Graves/CatGT_C_Waves_test/SC_artifact_test_data
    DST=$SRC/SC011_OUT
    ARGS="-dir=$SRC -run=SC011_022319 -g=0 -t=0,1 -prb_fld -prb=3"
    ARGS+=" -ap -aphipass=300 -gbldmx -gfix=0,0.1,0.02 -SY=3,-1,6,500"
    ARGS+=" -dest=$DST -out_prb_fld"
else
    ARGS=$@
fi

RUN_DIR=$(dirname ${BASH_SOURCE[0]})
export LD_LIBRARY_PATH=$RUN_DIR/links
$LD_LIBRARY_PATH/ld-linux-x86-64.so.2 --library-path $LD_LIBRARY_PATH $RUN_DIR/CatGT $ARGS

