
Channel mapping files, in general
=================================

SpikeGLX uses a simple text file to describe how acquired data channels should be ordered in graph windows. These are called channel mapping files and have '.cmp' extension. These files only affect displays within the software; they have nothing to do with the ordering of channels in recorded data files.

Below are a few lines from our example file: 'IMEC_PhsII_128Neural.nidq.cmp'.

	6,2,32,0,0 
	MN0C0;0 94
	MN0C1;1 90
	MN0C2;2 86
	MN0C3;3 82

The first line is a header. It describes how many channels of each type are being acquired. The header fields are interpreted like this:

	#Ni-Daq multiplexed neural channels:	6
	#Ni-Daq multiplexed analog channels:	2
	#channels/multiplexer:			32
	#Ni-Daq non-multiplexed analog chans:	0
	#Ni-Daq non-multiplexed digital words:	0

SpikeGLX requires that the channel types that you've set up in the Configure Dialog match the header in the mapping file, or it won't let you load that mapping file. See 'PhsII Configure Dialog.png' for the NI-DAQ channel setup strings that go with this mapping file.

After the header line, each line in a mapping file has an acquisition channel name followed by a graph number. A channel name might look like this:

	MN4C21;149

which means nidaq neural multiplexer 4 / multiplexer channel 21 ; 149th position in data stream. So a line in the mapping file like this:

	MN4C21;149 35

would mean acquired channel #149 is displayed as graph #149 when 'Acq Order' is in effect, and graph #35 when 'Usr Order' is applied.

You can edit these files to arrange the channels in any order you like.


Loading a mapping file
======================

Set up a new run using the Configuration Dialog.

- In the See N'Save tab::Channel mappings options box, click the NI 'Edit' button to show the Channel Map dialog.
- In the Channel Map dialog, click 'Load' to select your mapping file.
- Click 'OK' to close the dialog.


Sorting in the Graphs Window
============================

When your run starts, click 'Usr order' to sort the graphs according to your mapping file.


IMEC_PhsII_128Neural.nidq.cmp
=============================

In our example mapping file, channels progress from the tip of the shank upward. Even number channels are all on one edge of the shank and odd channels on the other edge. Reference channels are included and treated similarly. 

Because this file is set up for our usual 256-channel layout, the 128 mapped channels are followed by 64 unused neural channels, and then by 64 auxiliary analog channels in their acquisition order.






