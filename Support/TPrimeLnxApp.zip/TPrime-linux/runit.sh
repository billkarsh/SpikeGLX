#!/bin/sh

# You can't call TPrime directly, rather, call it via runit.sh.
# You can call runit.sh two ways:
#
# 1) > runit.sh cmd-line-parameters
# 2a) Edit parameters in runit.sh, then call it ...
# 2b) > runit.sh
#
# This script effectively says:
# "If there are no parameters sent to runit.sh, call TPrime
# with the parameters hard coded here, else, pass all of the
# parameters through to TPrime."
#

if [ "$1" == "" ]
then
    SRC=Y:/tptest/time_trans_01_g0_tcat
    DST=Y:/tptest
    ARGS="-syncperiod=1.0"
    ARGS+=" -tostream=$SRC.imec0.ap.SY_301_6_500.txt"
    ARGS+=" -fromstream=7,$SRC.nidq.XA_0_500.txt"
    ARGS+=" -events=7,$SRC.nidq.XA_1_7700.txt,$DST/out.txt"
else
    ARGS=$@
fi

export LD_LIBRARY_PATH=./links
./links/ld-linux-x86-64.so.2 --library-path ./links ./TPrime $ARGS

