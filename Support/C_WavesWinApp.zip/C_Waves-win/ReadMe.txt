
Purpose:
+ Mean waveforms calculator.
Run messages are appended to C_Waves.log in the current working directory.

Output:
+ 'mean_waveforms.npy': Array of mean waveforms (uV) with major-to-minor
+    dims {nClusters, nChannels, nSamples}. nChannels matches the channel
+    count of the spikeglx bin file. Non-neural 'waveforms' are zeroed.
+ 'cluster_snr.npy': 2-col table of snr for the peak channels with cols
+    {snr, nSpikes_in_snr}.

Usage:
>C_Waves < required_parameters > [ options ]

Required parameters:
-spikeglx_bin=<filepath>    ;spikeglx metafile required in same dir
-clus_table_npy=<filepath>  ;2-col table (uint32): {num_spike, pk-chan}
-clus_time_npy=<filepath>   ;1-col table (uint64): {spike_time} (ASCENDING ORDER)
-clus_lbl_npy=<filepath>    ;1-col table (uint32): {clus_lbl per spike_time}
-dest=<path>                ;output dir (must exist)
-samples_per_spike=82       ;waveform timepoints
-pre_samples=30             ;subset of samples_per_spike to left of peak
-num_spikes=1000            ;max waveforms included in averages
-snr_radius=8               ;disk radius (chans) about pk-chan, or zero

Options:
-chnexcl=0,3:5              ;exclude these acq chans from snr
-prefix=string              ;output files are named:
                            ;  'prefix_mean_waveforms.npy'
                            ;  'prefix_cluster_snr.npy'
-debug_npy                  ;log 1st 10 {table, time, lbl} entries then quit

Notes:
- SNR is calculated on a disk of channels (geometry from SGL shank map) of given radius about pk-chan. If -snr_radius=0 only the pk-chan is used for signal and noise estimation. If omitted the default radius is 8 channels.
- SNR signal is defined as peak-to-peak maximum on the average waveform, where highest and lowest voltages may appear anywhere in footprint.
- SNR noise is calculated as standard deviation of residuals of member waveforms on first 15 samples (left tail). This sampling strives to be insensitive to cluster contamination. For this to work as intended, -pre_samples should be at least 20.

- You can call C_Waves from a script.
- You can try it by editing the included 'runit.bat' file. Edit the file to set your own parameters. Then double-click the bat file to run it.
- Options must not have spaces.
- In *.bat files, continue long lines using <space><caret>. Like this ^.
- Remove all white space at line ends, especially after a caret (^).


Change Log
----------
Version 1.7
- Working/calling dir can be different from installed dir.
- Log file written to working dir.

Version 1.6
- Improved SNR estimator.

Version 1.5
- Smoother mean waveforms.

Version 1.4
- Support NP1010 probe.

Version 1.3
- -debug_npy option.
- Handle fortran-order npy files.
- Output npy headers are x64 size.

Version 1.2
- Uses 3A imro classes.
- Support for UHD-1 and NHP.

Version 1.1
- Remove 4GB binary file size limit.
- Faster.

Version 1.0
- Initial release.


