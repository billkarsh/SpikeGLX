GblDmx is a command line application that applies global demux filter to one imec.ap.bin file.

Call it like this:
> GblDmx "my_path/my_file.imec1.ap.bin"

The result is placed next to the source, named like this, with ".flt." added:
"my_path/my_file.flt.imec1.ap.bin"

Each run appends to the GblDmx.log file in the application directory.

You can call this from a script.

You can also try it by editing the included 'runit.bat' file. Edit the file to set your own path/file. Then double-click the bat file to run it.

