The SpikeGLX-x86_64.AppImage allows you to run the offline FileViewer and ShankViewer natively under Linux.

- Keep the AppImage and its helper folders together within the SpikeGLX_pkg folder.
- You may have to run >chmod +x SpikeGLX-x86_64.AppImage.
- You can run from the command-line, or, double-click on the AppImage file.

AppImages need the fuse2 package to run. If missing, install that in the way you usually add packages.

