
Purpose:
+ Join trials with given run_name and g-index in t-index range [ta,tb]...
+ ...Or run on any individual file.
+ Optionally apply bandpass and global demux CAR filters.
+ Optionally edit out saturation artifacts.
+ Optionally extract tables of TTL event times.

Output:
+ Results are placed next to source, named like this, with t-index = tcat:
+    path/run_name_g5_tcat.imec1.ap.bin.
+ Errors and run messages are appended to CatGT.log in the app folder.

Usage:
>CatGT -dir=data_dir -run=run_name -g=g -t=ta,tb <which streams> [ options ]

Usage notes:
+ It is easiest to run from a .bat file like the included example 'runit.bat'. Edit that file then double-click it to run.
+ Options must not have spaces.
+ In *.bat files, continue long lines using <space><caret>. Like this ^.
+ Read CatGT.log. There is no interesting output in the command window.

Which streams:
-ap               ;required to process ap streams
-lf               ;required to process lf streams
-ni               ;required to process ni stream
-prb_3A           ;if -ap or -lf process 3A-style probe files, e.g. run_name_g0_t0.imec.ap.bin
-prb=0,3:5        ;if -ap or -lf AND !prb_3A process these probes

Options:
-no_run_fld       ;older data generated before run folders were automatic
-prb_fld          ;use folder-per-probe organization
-t_miss_ok        ;instead of stopping, zero-fill if trial missing
-aphipass=300     ;apply ap high pass filter (float Hz)
-aplopass=9000    ;apply ap low  pass filter (float Hz)
-lfhipass=0.1     ;apply lf high pass filter (float Hz)
-lflopass=1000    ;apply lf low  pass filter (float Hz)
-gbldmx           ;apply ap global demux filter
-gblexcl=0,3:5    ;exclude these acq chans from ap gbldmx
-gfix=10,8        ;rmv ap artifacts: full-ht(%), span(smps)
-SY=0,384,6,10    ;extract TTL signal from imec SY (probe,word,bit,millisec)
-XA=2,3.0,0.08,25 ;extract TTL signal from nidq XA (word,thresh(v),min(V),millisec)
-XD=8,0,0         ;extract TTL signal from nidq xD (word,bit,millisec)
-dest=path        ;alternate path for output files (must exist)
-out_prb_fld      ;if using -dest, create output subfolder per probe

Parameter notes:
- The input run_name is a base (undecorated) name without g- or t-indices.
- The input files are expected to be organized as SpikeGLX writes them, that is:
  + If -no_run_fld option: data_dir/run_name_g0_t0.imec0.ap.bin.
  + No -prb_fld option: data_dir/run_name_g0/run_name_g0_t0.imec0.ap.bin.
  + If -prb_fld option: data_dir/run_name_g0/run_name_g0_imec0/run_name_g0_t0.imec0.ap.bin.
- Operate on a single t-index like this: -t=ta,ta.

- A meta file is also created, e.g.: path/run_name_g5_tcat.imec1.ap.meta.
- The meta file gets a tag indicating the actual range of t-indices used: 'catTVals=0,20'.

- gbldmx option:
  + Also use -aphipass to remove DC offsets.

- gfix option:
  + Light or chewing artifacts often make large amplitude excursions on a majority of channels. This tool identifies them (you specify a minimum amplitude for identification) and cuts them out, replacing with zeros (you specify how wide a cut to make).
  + Also use -aphipass to remove DC offsets.
  + The amplitude (%) can be fairly small since events must appear over large spatial area.
  + The blank-out span can be pretty short: 8 samples works for us.
  + Yes, -gbldmx and -gfix make sense used together.

- TTL (digital) extractions:
  + XA are analog-type NI channels. The signal is parametrized by index of the word, the low-to-high TTL threshold (V), minimum required amplitude (V), and milliseconds high.
  + For square pulses, set minimum <= thresh to ignore the minimum parameter and run more efficiently. For non-square pulses set minimum > thresh to ensure pulse attains desired amplitude.
  + SpikeGLX MA channels can also be scanned with the -XA option.
  + SY (imec), XD (NI) are digital-type channels. The signal is parametrized by index of word, index of bit in the word, and milliseconds high.
  + All indexing is zero-based.
  + Milliseconds high means the signal must persist above threshold for that long.
  + Milliseconds high precision is assumed to be +/- 20%.
  + Milliseconds high can be zero to specify detection of all rising edges regardless of pulse duration.
  + A given bit could encode two or more types of pulse that have different durations, E.g...
  + -SY=0,384,6,10 -SY=0,384,6,20 scans and reports both 10 and 20 ms pulses on the same line.
  + Each option, say -SY=0,384,6,10, creates output run_name_g0_tcat.imec0.SY384_6_20.txt.
  + The threshold is not encoded in the -XA filename; just word and millisec.
  + The files report the times (s) of leading edges of detected pulses; one time per line, <\n> line endings.
  + The time is relative to the start of the stream in which the pulse is detected (native time).

Change Log
----------
Version 1.1.
- Option -dest creates subfolder run_name_g0_tcat.
- Add option -out_prb_fld.
- Add tag 'fileCreateTime_original' to metadata.

Version 1.0.
- Initial release.


